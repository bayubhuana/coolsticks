<?php
get_header();
// layout_configurator(wp_is_mobile());
layout_configurator_minilapper(wp_is_mobile());
// layout_configurator_navnlapper(wp_is_mobile());
get_footer();
?>